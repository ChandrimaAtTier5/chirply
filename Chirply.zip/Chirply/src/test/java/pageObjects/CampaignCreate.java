package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

//import utils.TestContextSetup;

public class CampaignCreate {	
	
	public  WebDriver driver;
	
	//TestContextSetup testContextSetup;
	public CampaignCreate(WebDriver driver)
{
		this.driver= driver;
}


	public By createCamp =By.xpath("//h1 [ text() ='Create New Campaign']");
	By campName= By.name("campaignName");
	By savebutton =By.xpath("//button[@id='createCampaign']");
	public By newStepText = By.xpath("//*[@id=\"app\"]/div/div/div[2]/div[1]/div[1]/h2");
	public By campaignName = By.xpath("//h1[contains(text(),'Add New Step ( Campaign test )')");
	public By timingbox=By.cssSelector("stepTiming");
	By immediateTime = By.xpath("//input[@id='selectImmed']");
	public By actionbox= By.cssSelector("stepActions");
	By smsAction =By.xpath("//input[@id='smsConfig']");
	public By contentbox= By.cssSelector("stepContent");
	By contentAdd =By.xpath("//input[@id='addSms']");
	public By writemessage =By.xpath("//label [ text() ='Write Your Message']");
	By writeContent= By.xpath("//textarea[@id='messageBodyNew']");
	By keyword =By.name("fname");
	By savebtn = By.className("saveStepButton");
	public By addNewStep = By.xpath("//*[@id=\"app\"]/div/div/div[2]/div[2]/a/button");
	By minutesTime = By.xpath("//input[@id='selectMinutes']");
	By minuteInput =By.xpath("//input[@id='minutes']");
	public By stepname =By.xpath("//body/div[@id='app']/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/input[1]");
	
	public void campName() {
		driver.findElement(campName).sendKeys("Campaign test");
	}
	
	public void campCreate() {
		System.out.println("step driver: "+driver);
		driver.findElement(savebutton).click();
	}
	
	public void stepName() {
	
		driver.findElement(stepname).sendKeys("Step 1");
	}
	
	public void clickImmediate() {
		driver.findElement(immediateTime).click();
	}
	
	public void clickMinutes() {
		driver.findElement(minutesTime).click();
	}
	
	public void clickSms() {
		driver.findElement(smsAction).click();
	}
	public void contentAdd() {
		driver.findElement(contentAdd).click();
	}
	
	public void writeContent() {
		driver.findElement(writeContent).sendKeys("This is the text message by automation script");
	}
	
	public void writeKeyword() {
		driver.findElement(keyword).click();
	}
	
	public void ClickonSave() {
		driver.findElement(savebtn).click();
	}
	
	public void ClickStep() {
		driver.findElement(addNewStep).click();
	}
	//public boolean addstep() {
		//return driver.findElement(addNewStep).isEnabled();
	//}
	public void minuteInput() {
		driver.findElement(minuteInput).sendKeys(Keys.ARROW_UP);
	}
	
}
