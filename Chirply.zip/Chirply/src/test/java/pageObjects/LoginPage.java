package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	public  WebDriver driver;
	public LoginPage(WebDriver driver)
	{
		this.driver= driver;
	}

	By loginbtn = By.linkText("Login");
	By email =By.name("email");
	By Password =By.name("password");
	public  By DashboardText= By.xpath("//*[@id=\"app\"]/div/div/div[1]/div[1]/h1");
	public By CampText=By.xpath("//span[ text() = 'Campaigns']");
	 By CampMenu=By.xpath("/html/body/div[1]/div/ul/li[10]/a");
	public static By CreateCamptext=By.xpath("//h1[ text() = 'Campaigns']");
	By Createcampbutton =By.xpath("//*[@id=\"app\"]/div/div/div[1]/a/button");
	By clicklogin =By.id("postLoginInfo");
	
	
	
	public void loginTest() {
		driver.findElement(loginbtn).click();
	}

   public void email(String Email) {
	   driver.findElement(email).sendKeys(Email);
   }
    
  public void password(String password) {
	  driver.findElement(Password).sendKeys(password);
  }
   public void clickLogin() {
	   driver.findElement(clicklogin).click();
   }
   public  void campTest() {
	   driver.findElement(CampMenu).click();
   }
   
   public void createCamp() {
	   driver.findElement(Createcampbutton).click();
   }

   
   
}




