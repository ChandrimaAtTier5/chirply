package pageObjects;
import org.openqa.selenium.WebDriver;



public class PageObjectManager {
	
	public CampaignPage campaignpage;
	public LoginPage loginpage;
	
	public WebDriver driver;
	
	public PageObjectManager(WebDriver driver) {
		this.driver= driver;
	}
	
	public LoginPage  Getloginpage() {
		loginpage = new LoginPage(driver);
			return loginpage;
		}
	public CampaignPage  GetCampaignPage() {
		campaignpage = new CampaignPage(driver);
			return campaignpage;
		}

	}


