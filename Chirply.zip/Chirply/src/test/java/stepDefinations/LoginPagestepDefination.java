package stepDefinations;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.CampaignCreate;
import pageObjects.LoginPage;
//import pageObjects.pageObjectManager;
//import utils.TestContextSetup;

public class LoginPagestepDefination {
	

	  WebDriver driver;

  //  TestContextSetup testContextSetup;
   // pageObjectManager pageobjectmanager;
    public  LoginPage Loginpage;
   
 /*   public LoginPagestepDefination(TestContextSetup testContextSetup) {
   	 this.testContextSetup = testContextSetup;
   	 
    }
   */
	 @Given("^User navigate to home page and click on login button$")
	    public void user_navigate_to_home_page() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tier 5 Support\\chromedriver\\chromedriver.exe");       
		 driver = new ChromeDriver(); 
		driver.manage().window().maximize();
		driver.get("https://stage.chirply.io/");
		LoginPage loginpage = new LoginPage(driver);
		//Loginpage= testContextSetup.pageobjectmanager.loginpage(testContextSetup.driver);
		 loginpage.loginTest();
	   }

	  @When("^User enters Username as (.+) and Password as (.+)$")
	    public void user_enters_username_as_and_password_as(String username, String password) throws Throwable {
		 // Loginpage= testContextSetup.pageobjectmanager.loginpage(testContextSetup.driver);
		  LoginPage loginpage = new LoginPage(driver);
		  loginpage.email(username);
		  loginpage.password(password);
		  
	    }

	  @Then("^click on login and verify dashboard text$")
	    public void click_on_login_and_verify_dashboard_text() throws Throwable {
		//  Loginpage= testContextSetup.pageobjectmanager.loginpage(testContextSetup.driver);
		  LoginPage loginpage = new LoginPage(driver);
		  loginpage.clickLogin();
	        try {
				if(loginpage.DashboardText != null)
					System.out.println("User is sucessfully loggedin ");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Dashbaord text is not present");
			}
	        }
	  @Then("^User click on Campaign menu item$")
	    public void user_click_on_campaign_menu_item() throws Throwable {
		//  Loginpage= testContextSetup.pageobjectmanager.loginpage(testContextSetup.driver);
		  LoginPage loginpage = new LoginPage(driver);
		  if(loginpage.CampText !=null)
			  loginpage.campTest();
          }
	  
	  @Then("^User is in campaign page and click on \"([^\"]*)\" page$")
	    public void user_is_in_campaign_page_and_click_on_something_page(String strArg1) throws Throwable {
		 // Loginpage= testContextSetup.pageobjectmanager.loginpage(testContextSetup.driver);
		  LoginPage loginpage = new LoginPage(driver);
	           if(loginpage.CreateCamptext != null)
	                    System.out.println("Campaign page shows");
	           loginpage.createCamp();
	         
	  }
	  @Then("^Create New Campaign page is open$")
	    public void create_new_campaign_page_is_open() throws Throwable {

	     //  CampaignCreate = testContextSetup.pageobjectmanager.campaigncreate(testContextSetup.driver);
	       CampaignCreate campaigncreate = new CampaignCreate(driver);
	      if(campaigncreate.createCamp !=null)
	        System.out.println("Creating new campaign shows");
	    }
	  
	  @Then("^User provide the campaign name$")
	    public void user_provide_the_campaign_name() throws Throwable {
		//  CampaignCreate= testContextSetup.pageobjectmanager.campaigncreate(testContextSetup.driver);
		  CampaignCreate campaigncreate = new CampaignCreate(driver);
		  campaigncreate.campName();
		  }
	  
	  @Then("^Clicking on Save button$")
	    public void clicking_on_save_button() throws Throwable {
		  Thread.sleep(3000);
		//  CampaignCreate= testContextSetup.pageobjectmanager.campaigncreate(testContextSetup.driver);
		  CampaignCreate campaigncreate = new CampaignCreate(driver);
		  campaigncreate.campCreate();
		  Thread.sleep(3000);
		 }
	  @Then("^Add New Step Page is open$")
	    public void add_new_step_page_is_open() throws Throwable {
		//  CampaignCreate= testContextSetup.pageobjectmanager.campaigncreate(testContextSetup.driver);
		  CampaignCreate campaigncreate = new CampaignCreate(driver);
		 if( campaigncreate.newStepText != null)
		  System.out.println("Add new step page is open");
	    }
	
	       
	  @Then("^Provide step name$")
	    public void _provide_step_name_something() throws Throwable {
		//  CampaignCreate= testContextSetup.pageobjectmanager.campaigncreate(testContextSetup.driver);
		  CampaignCreate campaigncreate = new CampaignCreate(driver);
		  campaigncreate.stepName();
	     
	  }
	
	  @Then("Timing box shows and click on immediate$")
	       public void timing_box_shows() throws InterruptedException {
	    	 //  CampaignCreate= testContextSetup.pageobjectmanager.campaigncreate(testContextSetup.driver);
	    	   CampaignCreate campaigncreate = new CampaignCreate(driver);
	           if(campaigncreate.timingbox!= null) {
	        	   System.out.println("Timing delay box opens");
	        	   Thread.sleep(2000);
	        	   campaigncreate.clickImmediate();
	        	   
	           };
	          
	       }
	  @Then("^Action box shows and click on SMS$")
	    public void action_box_shows_and_click_on_sms() throws Throwable {
	       //    CampaignCreate= testContextSetup.pageobjectmanager.campaigncreate(testContextSetup.driver);
	           CampaignCreate campaigncreate = new CampaignCreate(driver);
	           if(campaigncreate.actionbox!= null) {
	        	   System.out.println("Action box opens");
	        	   Thread.sleep(2000);
	        	   campaigncreate.clickSms();
	        	   
	           };
	      

	    }
	  
	  @Then("^Content box open and click on \"([^\"]*)\"$")
	    public void content_box_open_and_click_on_something(String strArg1) throws Throwable {
		//  CampaignCreate= testContextSetup.pageobjectmanager.campaigncreate(testContextSetup.driver);
		  CampaignCreate campaigncreate = new CampaignCreate(driver);
        if(campaigncreate.contentbox!= null) {
     	   System.out.println("Content box opens");
     	   Thread.sleep(2000);
     	  campaigncreate.contentAdd();
     	   
        };
	    }
	  
	  @And("^Write content here$")
	    public void write_content_here() throws Throwable {
		 // CampaignCreate= testContextSetup.pageobjectmanager.campaigncreate(testContextSetup.driver);
		  CampaignCreate campaigncreate = new CampaignCreate(driver);
		  System.out.println("ADD NEW STEP PREVIOUS RUN" +     driver);
		if(campaigncreate.writemessage!= null) {
	       	   System.out.println("Now we can write messages");
	       	   Thread.sleep(2000);
	       	campaigncreate.writeContent();
	       	campaigncreate.writeKeyword();
	       	campaigncreate.ClickonSave();
	       	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	       	wait.until(ExpectedConditions.visibilityOfElementLocated(campaigncreate.addNewStep));
	       	campaigncreate.ClickStep();
	       	    };
	    }
	 
	  @Given("Click on new step and Provide step name")
	  public void click_on_new_step_and_provide_step_name() {
	      // Write code here that turns the phrase above into concrete actions
		  CampaignCreate campaigncreate = new CampaignCreate(driver);
		  campaigncreate.stepName();
	  }

	    @When("^Timing box shows and click on minutes$")
	    public void timing_box_shows_and_click_on_minutes() throws Throwable {
	    	System.out.println("step445");
	    }

	    @Then("^Provide minutes$")
	    public void provide_minutes() throws Throwable {
	    	System.out.println("step46");
	    }

	    @Then("^Email box open and clicking \"([^\"]*)\"$")
	    public void email_box_open_and_clicking_something(String strArg1) throws Throwable {
	    	System.out.println("step7");
	    }

	    @And("^Action box shows and click on Email$")
	    public void action_box_shows_and_click_on_email() throws Throwable {
	    	System.out.println("step48");
	    }

	    @And("^Write subject and content here$")
	    public void write_subject_and_content_here() throws Throwable {
	    	System.out.println("step494");
	    }
	  
	  
	 
    
}
