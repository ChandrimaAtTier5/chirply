package stepDefinations;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.CampaignPage;
import pageObjects.LoginPage;
import pageObjects.PageObjectManager;
import utils.TestBase;
import utils.TextContentSetup;
import pageObjects.PageObjectManager;
import utils.TextContentSetup;

public class LoginPagestepDefination {
	public WebDriver driver;
     TextContentSetup textcontentsetup;
     PageObjectManager pageobjectmanager;
     public  LoginPage loginpage;
     TestBase testbase;
   
   public LoginPagestepDefination(TextContentSetup textcontentsetup) {
   	 		this.textcontentsetup=textcontentsetup;
   	 	loginpage=  textcontentsetup.pageobjectmanager.Getloginpage();
   }
 
   
	 @Given("^User navigate to home page and click on login button$")
	    public void user_navigate_to_home_page() throws Throwable {
		loginpage.loginTest();
	   }

	  @When("^User enters Username as (.+) and Password as (.+)$")
	    public void user_enters_username_as_and_password_as(String username, String password) throws Throwable {
		  loginpage.email(username);
		  loginpage.password(password);
		  
	    }

	  @Then("^click on login and verify dashboard text$")
	    public void click_on_login_and_verify_dashboard_text() throws Throwable {
		 loginpage.clickLogin();
	        try {
				if(loginpage.DashboardText != null)
					System.out.println("User is sucessfully loggedin ");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Dashbaord text is not present");
			}
	        }
	  
	  
	  
	 
    
}
