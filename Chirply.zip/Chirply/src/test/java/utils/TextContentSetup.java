package utils;

import java.io.IOException;

import org.openqa.selenium.WebDriver;

import pageObjects.PageObjectManager;

public class TextContentSetup {
	
	public WebDriver driver;
	public PageObjectManager pageobjectmanager;
	public TestBase testbase;
	
	public TextContentSetup() throws IOException {
		 testbase = new TestBase();
		 pageobjectmanager = new PageObjectManager(testbase.WebDriverManager());
		// genericutils = new GenericUtils(testbase.WebDriverManager());
		
		}

}
