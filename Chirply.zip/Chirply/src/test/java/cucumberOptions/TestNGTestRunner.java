
package cucumberOptions;




import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(
       features="src/test/java/AppFeatures/",
       glue="stepDefinations",
       monochrome=true,
      
      
       plugin = { "pretty" ,"html:target/cucumber-reports.html"},
       tags="@loginTest or @campTest"
       )

public class TestNGTestRunner extends AbstractTestNGCucumberTests{

}
